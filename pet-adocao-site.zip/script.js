function adotar(nomePet){
document.getElementById('formulario').style.display='block';
document.getElementById('petSelecionado').value=nomePet;
}
function enviarFormulario(event){
event.preventDefault();
const nome=document.getElementById('nome').value;
const pet=document.getElementById('petSelecionado').value;
document.getElementById('mensagem').innerHTML=`✅ Obrigado, ${nome}! Solicitação para ${pet} enviada.`;
event.target.reset();
}